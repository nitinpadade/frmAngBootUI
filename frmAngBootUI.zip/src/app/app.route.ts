import { RouterModule, Routes } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { LoginComponent } from './login/login.component'
import { LoginLayoutComponent } from './layout/login-layout/login-layout.component';
import { MasterLayoutComponent } from './layout/master-layout/master-layout.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LogoutComponent } from './logout/logout.component';
import { UsersComponent } from './users/users.component';

export const AppRoutes: Routes = [
  {
    path: '',
    component: LoginLayoutComponent,
    children: [
      { path: '', component: LoginComponent, pathMatch: 'full' },
      { path: 'login', component: LoginComponent }
    ]
  },
  {
    path: '',
    component: MasterLayoutComponent,
    children: [
      { path: 'dashboard', component: DashboardComponent, pathMatch: 'full' },
      { path: 'users', component: UsersComponent },
      { path: 'logout', component: LogoutComponent },
      /*{ path: 'adduser/:id', component: AdduserComponent },
      { path: 'employeer-profile', component: EmployeerProfileComponent },
      { path: 'add-employer-profile', component: AddEmployerProfileComponent },
      { path: 'jobseeker-profile', component: JobseekerProfileComponent },
      { path: 'addjobseekerprofile', component: AddjobseekerprofileComponent }*/

    ]
  },
  { path: '**', redirectTo: '' }
];

export const routing: ModuleWithProviders = RouterModule.forRoot(AppRoutes, { onSameUrlNavigation: 'reload' });